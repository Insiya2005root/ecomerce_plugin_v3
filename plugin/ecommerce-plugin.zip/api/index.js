"use strict";
function isPublicPluginRoute(method, rawPath) {
    const upperMethod = String(method || 'GET').toUpperCase();
    const normalizedPath = String(rawPath || '')
        .replace(/\/+/g, '/')
        .replace(/^\//, '')
        .replace(/\/$/, '');
    if (upperMethod === 'GET') {
        if (normalizedPath === 'health' ||
            normalizedPath === 'storefront/health' ||
            normalizedPath === 'storefront/settings' ||
            normalizedPath === 'storefront/categories' ||
            normalizedPath === 'storefront/products' ||
            normalizedPath === 'storefront/pincode' ||
            /^storefront\/products\/[^/]+$/.test(normalizedPath) ||
            /^storefront\/pages\/(shop|product|cart|checkout)$/.test(normalizedPath)) {
            return true;
        }
    }
    if (upperMethod === 'POST') {
        if (normalizedPath === 'cart/calculate' || normalizedPath === 'storefront/checkout' || normalizedPath === 'storefront/order-lookup') {
            return true;
        }
    }
    return false;
}
module.exports = {
    async register({ app, cms }) {
        // Replace default '/health'-only auth middleware with explicit method+path public allowlist
        // while keeping all Admin CRUD and configuration routes strictly protected.
        // Storefront pages are created with no owner; the first signed-in admin becomes their owner so they
        // appear in OpenExt's Pages list (checked at most once a minute, never delays the request).
        let lastOwnerCheck = 0;
        const adoptStorefrontPages = (userId) => {
            if (typeof userId !== 'string' || Date.now() - lastOwnerCheck < 60_000)
                return;
            lastOwnerCheck = Date.now();
            const { StorefrontBlueprintService } = require('./services/StorefrontBlueprintService');
            StorefrontBlueprintService.adoptOwnerlessPages('default_tenant', userId).catch((err) => cms.logger?.warn?.('Could not set the owner of the storefront pages.', err));
            // Once per site: a default Header/Footer in OpenExt Pages when the site has none.
            require('./services/SiteChromeService').SiteChromeService.ensureDefaultHeaderFooter('default_tenant', userId).catch((err) => cms.logger?.warn?.('Could not add the default site header/footer.', err));
        };
        const strictAuthMiddleware = async (req, res, next) => {
            if (!isPublicPluginRoute(req?.method, req?.path) && !req?.user) {
                res.status(401).json({ message: 'Unauthorized' });
                return;
            }
            if (req?.user?.userId)
                adoptStorefrontPages(req.user.userId);
            await next();
        };
        if (Array.isArray(app?.middlewares) && app.middlewares.length > 0) {
            app.middlewares[0] = strictAuthMiddleware;
        }
        else if (typeof app?.use === 'function') {
            app.use(strictAuthMiddleware);
        }
        await require('./models/Product').register(cms);
        await require('./models/Category').register(cms);
        await require('./models/Order').register(cms);
        await require('./models/Settings').register(cms);
        await require('./models/TaxClass').register(cms);
        await require('./models/TaxRule').register(cms);
        await require('./models/Location').register(cms);
        await require('./models/DiscountRule').register(cms);
        await require('./models/StorefrontPage').register(cms);
        await require('./models/Collection').register(cms);
        await require('./models/AdminProfile').register(cms);
        await require('./models/Inventory').register(cms);
        require('./routes/products')(app);
        require('./routes/categories')(app);
        require('./routes/collections')(app);
        require('./routes/dashboard')(app);
        require('./routes/settings')(app);
        require('./routes/taxes')(app);
        require('./routes/locations')(app);
        require('./routes/cart')(app);
        require('./routes/checkout')(app);
        require('./routes/orders')(app);
        require('./routes/customers')(app);
        require('./routes/inventory')(app);
        require('./routes/discounts')(app);
        require('./routes/storefront')(app);
        require('./routes/storefrontCheckout')(app);
        // Products created before inventory existed get their inventory items (stock moves to the primary location).
        try {
            await require('./services/InventoryService').InventoryService.syncAll();
        }
        catch (err) {
            cms.logger?.warn?.('Inventory sync failed; it will be retried on the next start.', err);
        }
        try {
            const { StorefrontBlueprintService } = require('./services/StorefrontBlueprintService');
            await StorefrontBlueprintService.ensureProvisionedForTenant('default_tenant');
        }
        catch {
            // Provisioning will also run lazily on storefront page requests
        }
    },
    boot({ cms }) {
        cms.logger.info('E-Commerce plugin booted successfully with TypeScript.');
    },
    shutdown() { }
};
